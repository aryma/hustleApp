/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
var app = {
    // Application Constructor
    initialize: function() {
        document.addEventListener('deviceready', this.onDeviceReady.bind(this), false);
        document.addEventListener("deviceready", function () { runningInCordova = true; }, false);
        
                document.addEventListener("backbutton", onBackKeyDown(), false);
        function onBackKeyDown() {
            // Handle the back button
            window.history.back();
            
        }
    
       
      
        
    },

    // deviceready Event Handler
    //
    // Bind any cordova events here. Common events are:
    // 'pause', 'resume', etc.
    onDeviceReady: function() {
        this.receivedEvent('deviceready');
        document.addEventListener("offline", checkConnection, false);
        function checkConnection() {
    var networkState = navigator.connection.type;
    var states = {};
    states[Connection.NONE]     = 'No network connection';
    if (states[Connection.NONE]) myApp.alert(states[networkState]);
    }
 //PERMESSI DI NOTIFICA IOS
        window.FirebasePlugin.grantPermission();

        //PRIMA VOLTA SI REGISTRA IL TOKEN
        window.FirebasePlugin.getToken(function(token) {
            // save this server-side and use it to push notifications to this device
            localStorage.setItem("fcmToken", token);
            window.FirebasePlugin.subscribe("newsHustle");
            //console.log(token);
        }, function(error) {
            console.error(error);
            //alert('errore nel generare il tuo identificativo');
        });

        // SECONDA VOLTA LO COPNTROLLA EVENTUALMENTE LO CAMBIA
        window.FirebasePlugin.onTokenRefresh(function(token) {
            // save this server-side and use it to push notifications to this device
            localStorage.setItem("fcmToken", token);
            window.FirebasePlugin.subscribe("newsHustle");
            //console.log(token);
                       
        }, function(error) {
            console.error(error);
        });


        //GESTIONE NOTIFICHE
        window.FirebasePlugin.onNotificationOpen(function(notification) {
            console.log(notification);
        }, function(error) {
            console.error(error);
        });
    },

    // Update DOM on a Received Event
    receivedEvent: function(id) {
        var parentElement = document.getElementById(id);
        var listeningElement = parentElement.querySelector('.listening');
        var receivedElement = parentElement.querySelector('.received');

        listeningElement.setAttribute('style', 'display:none;');
        receivedElement.setAttribute('style', 'display:block;');

        console.log('Received Event: ' + id);
    }
};

app.initialize();